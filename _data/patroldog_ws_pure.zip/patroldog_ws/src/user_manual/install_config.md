
## Must allocate 16G swap for compiling liosam
```
sudo dd if=/dev/zero of=/swapfile bs=64M count=256 status=progress

sudo chmod 600 /swapfile

sudo mkswap /swapfile

sudo swapon /swapfile

free -h
```

## install openslam_gmapping
```
sudo apt install ros-melodic-openslam-gmapping
```

## install gtsam-4.0.2
摘录自： https://github.com/TixiaoShan/LIO-SAM

Note that we need to install the specified version of 4.0.2 here. 
The newest version of gtsam, such as 4.1 will cause compiling problem `/usr/bin/ld: cannot find -lBoost::timer`.

[GTSAM](https://github.com/borglab/gtsam/releases): Georgia Tech Smoothing and Mapping library

Steps to install gtsam-4.0.2 are as follows:
```
wget -O ~/Downloads/gtsam.zip https://github.com/borglab/gtsam/archive/4.0.2.zip
cd ~/Downloads/ && unzip gtsam.zip -d ~/Downloads/
cd ~/Downloads/gtsam-4.0.2/
mkdir build && cd build
cmake -DGTSAM_BUILD_WITH_MARCH_NATIVE=OFF -DGTSAM_USE_SYSTEM_EIGEN=ON ..
sudo make install -j8
```

## controller-manager

```
sudo apt install ros-melodic-controller-manager
```

## libpcap-dev
```
sudo apt install libpcap-dev
```

## Conflict of PCL and OpenCV
- [PCL-OpenCV冲突的解决方案](https://blog.csdn.net/weixin_41698305/article/details/120651431)
- <https://github.com/strands-project/strands_3d_mapping/issues/67>

## 安装 `unitree_legged_sdk`

下载与编译

```
cd ~/Unitree/sdk
git clone https://github.com/unitreerobotics/unitree_legged_sdk.git
cd unitree_legged_sdk
mkdir build
cd build
cmake ../
make
```

配置环境变量
```
echo "export UNITREE_LEGGED_SDK_PATH=~/Unitree/sdk/unitree_legged_sdk" >> ~/.bashrc
```

## 
Error:
```
/home/unitree/Unitree/autostart/patroldog_ws/devel/lib/lio_sam/lio_sam_mapOptmization: error while loading shared libraries: libmetis.so: cannot open shared object file: No such file or directory
```

Reference:
```
https://blog.csdn.net/weixin_43807148/article/details/113772781
```

Method:
```
sudo cp /usr/local/lib/libmetis.so /usr/lib
```

## LIO-SAM编译问题
- [LIO-SAM编译问题](https://blog.csdn.net/m0_38144614/article/details/116614157)
- [LIO-SAM源码解析：准备篇 - 卢涛的文章 - 知乎](https://zhuanlan.zhihu.com/p/352039509)
- [PCL-OpenCV冲突的解决方案](https://blog.csdn.net/weixin_41698305/article/details/120651431)
- <https://github.com/TixiaoShan/LIO-SAM/issues/181>

测试LIO-SAM，编译期报错：
`error: field ‘param_k_’ has incomplete type ‘flann::SearchParams`

To resolve:
- In CMakeLists.txt, move the cv_bridge and all OpenCV related after PCL related.



